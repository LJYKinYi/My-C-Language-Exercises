#include <stdio.h>

int main() {
    struct Person {
        int age;
        // char *name;
        char name[10];

    };
    struct Person person={10,"John"};
    // person.age = 10;
    // person.name= "John";

    printf("person.age=%d\n",person.age);
    printf("person.name=%s\n",person.name);

}