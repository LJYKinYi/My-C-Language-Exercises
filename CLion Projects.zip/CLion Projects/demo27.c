//
// Created by kinyi on 25-3-19.
//
//字符串的基本使用
#include <stdio.h>

int main() {
    char word[] = {'H', 'e', 'l', 'l', 'o'}; //字符数组
    char word1[] = "Hello"; //字符串
    int i;
    for (i = 0; i < sizeof(word) / sizeof(word[0]); i++) {
        printf("%c", word[i]);
    }
    char *s = "Hello World";
    char *s2 = "Hello World";

    char str[] = "Hello";
    str[0] = 'B';
    printf("\n");
    printf("%zu\n", sizeof(word)); //字符数组长度
    printf("%zu\n", sizeof(word1)); //字符串长度
    printf("%zu\n", sizeof(word) / sizeof(word[0])); //字符数组的字符个数
    printf("%zu\n", sizeof(word1) / sizeof(word1[0])); //字符串的字符个数

    printf("%s\n", str);

    printf("%p\n", s);
    printf("%p\n", s2);
    return 0;
}
