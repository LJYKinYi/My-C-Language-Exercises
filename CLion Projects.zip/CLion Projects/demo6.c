//
// Created by kinyi on 25-3-3.
//
//if������ŵ�ʹ��
#include <stdio.h>

int main() {
    int a;
    int b;
    int c;
    int max = 0;
    scanf("%d %d %d", &a, &b, &c);
    if (a > b) {
        if (a > c) {
            max = a;
        } else {
            max = c;
        }
    } else {
        if (b > c) {
            max = b;
        } else {
            max = c;
        }
    }
    printf("%d", max);
    return 0;
}


