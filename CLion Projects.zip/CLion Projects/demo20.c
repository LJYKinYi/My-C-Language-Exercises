//
// Created by kinyi on 25-3-12.
//

//���ú������
#include <stdio.h>
void sum(int home, int end) {
    int sum = 0;
    int i;
    for (i = home; i <= end; i++) {
        sum += i;
    }
    printf("%d��%d�ĺ���%d\n", home, end, sum);
}


int main() {
    sum(1, 10);
    sum(20, 30);
    sum(35, 45);
    return 0;
}
