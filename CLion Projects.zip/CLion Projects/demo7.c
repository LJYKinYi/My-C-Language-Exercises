//
// Created by kinyi on 25-3-5.
//
//switch�������
#include <stdio.h>
int main() {
    int type ;
    printf("�������� : \n");
    scanf("%d",&type);
    switch(type) {
        case 1:
            printf("C����");
        break;
        case 2:
            printf("Cpp");
        break;
        case 3:
            printf("c#");
        break;
        case 4:
            printf("Java");
        break;
        default:
            printf("Error");
    }
    return 0;
}