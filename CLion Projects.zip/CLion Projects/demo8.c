//
// Created by kinyi on 25-3-5.
//
//whileѭ�����
#include <stdio.h>

int main() {
    int x;
    int n = 1;
    printf("����������:\n");
    scanf("%d", &x);
    x /= 10;
    printf("%d\n", x);

    while (x != 0) {
        x /= 10;
        n++;
        printf("%d\n", x);
    }
    printf("%d\n", n);
    return 0;
}
