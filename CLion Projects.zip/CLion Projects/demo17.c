//
// Created by kinyi on 25-3-10.
//
//whileѭ��ʵ�־žų˷���
#include<stdio.h>

int main() {
    int i = 1;
    int j;
    int n;
    printf("�������֣�\n");
    scanf("%d", &n);
    while (i <= n) {
        j = 1;
        while (j <= i) {
            printf("%d*%d=%d ", j, i, i * j);
            if (i * j < 10) {
                printf("   ");
            } else {
                printf("  ");
            }
            j++;
        }
        printf("\n");
        i++;
    }
    return 0;
}
