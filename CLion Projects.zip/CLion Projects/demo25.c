//
// Created by kinyi on 25-3-17.
//
//ָ��Ĺ�ϵ
#include <stdio.h>

int main() {
    int a = 10;
    int *p = &a;
    *p = 20;
    printf("a =%d\n", a);
    printf("*p=%d\n", *p);

    printf("p=%p\n", p);
    printf("a=%p\n", &a);
}
