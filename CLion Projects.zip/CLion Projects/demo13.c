//
// Created by kinyi on 25-3-7.
//
//n�Ľ׳�
#include <stdio.h>

int main() {
    int i=1;
    int n;
    int sum = 1;
    printf("����n��ֵ��\n");
    scanf("%d", &n);
    do{
        sum = sum * i;
        i++;
    }while (i <= n) ;
    printf("sum=%d\n", sum);
    return 0;
}
