//
// Created by kinyi on 25-3-5.
//
//do while ѭ��
#include <stdio.h>

int main() {
    int x;
    int n = 0;
    printf("��������:\n ");
    scanf("%d", &x);
    do {
        x /= 10;
        n++;
        printf("%d\n", x);
    } while (x != 0);
    printf("%d", n);
}
