//
// Created by kinyi on 25-3-9.
//
//forѭ��ȡ���Լ��
#include <stdio.h>

int main() {
    int a;
    int b;
    int min;
    int i;
    int ret;
    printf("��������: \n");
    scanf("%d %d", &a, &b);
    if (a < b) {
        min = a;
    } else {
        min = b;
    }
    for (i = min; i <= min; i--) {
        if (a % i == 0) {
            if (b % i == 0) {
                ret = i;
                goto out;
            }
        }
    }
    out:
        printf("%d\n", ret);
    return 0;
}
